<?php

namespace App\Admin\Controllers;

use App\Admin\Repositories\WxSetting;

//use Dcat\Admin\Form;
use App\Dengje\Utils\Settings;
use Dcat\Admin\Grid;
use Dcat\Admin\Show;
use Dcat\Admin\Controllers\AdminController;
use Dcat\Admin\Layout\Content;
use Dcat\Admin\Widgets\Form;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use function Clue\StreamFilter\fun;

class WxSettingController extends Form
{
//    use PreviewCode;


    protected $options = [
        0 => '是',
        1 => '否',
    ];


    public function handle(array $input)
    {
        // $input是你接收到的表单数据
        // 在这里可以写你的处理逻辑


        // 第一个参数是响应的成功信息，第二个参数是要跳转的路由
        return $this->response()->success('Processed successfully.')->refresh();
    }

    public function index(Content $content)
    {
        return $content->title('微信小程序')
//            ->body($this->buildPreviewButton())
//            ->body($this->newline())
            ->body(
                <<<HTML
<div class="card">{$this->form()->render()}</div>
HTML
            );
    }

    protected function form()
    {
        // Since v1.6.5 弹出确认弹窗


        $form = new Form();
        $form->confirm('您确定要提交表单吗？', 'content');
        $form->disableResetButton();
        $form->tab('小程序设置', function (Form $form) {

            $form->text('app_id','AppID')->help('前往：https://mp.weixin.qq.com/')->value(Settings::get('app_id'));
            $form->password('app_secret')->help('前往：https://mp.weixin.qq.com/')->value(Settings::get('app_secret'));
            $form->text('mch_id','商户号')->help('前往：https://pay.weixin.qq.com/')->value(Settings::get('mch_id'));
            $form->password('mch_secret','商户密钥')->help('前往：https://pay.weixin.qq.com/')->value(Settings::get('mch_secret'));

        });

        $form->tab('基本设置', function (Form $form) {

            $form->radio('is_audit_posts', '发帖是否需要审核')->options($this->options)->default(0)->value(Settings::get('is_audit_posts'));
            $form->radio('is_audit_comment', '评论是否需要审核')->options($this->options)->default(0)->value(Settings::get('is_audit_comment'));
            $form->radio('is_audit_user_info', '修改用户资料是否需要审核')->options($this->options)->default(0)->value(Settings::get('is_audit_user_info'));
            $form->radio('is_user_center_show_posts', '未审核通过的帖子是否在个人中心显示')->options($this->options)->default(0)->value(Settings::get('is_user_center_show_posts'));
            $form->radio('is_audit_create_cirlce', '新增圈子是否需要审核')->options($this->options)->default(0)->value(Settings::get('is_audit_create_cirlce'));

        });
        $form->tab('小程序个性化配置',function (Form $form) {
            $form->text('app_title','小程序名称')->value(Settings::get('app_title'));
            $form->text('app_intro','小程序简介')->value(Settings::get('app_intro'));
            $form->image('app_login_bg','登录背景图')->default(Settings::get('app_login_bg'))->help('建议图片宽为750px')->url('files/uploads');
            $form->image('official_popup_poster','官方弹窗海报')->default(Settings::get('official_popup_poster'))->help('建议图片大小为500px')->url('files/uploads');
            $form->image('authentication_popup_poster','认证弹窗海报')->default(Settings::get('authentication_popup_poster'))->url('files/uploads');
            $form->image('user_background_maps','用户默认背景')->default(Settings::get('user_background_maps'))->url('files/uploads');;


        });
        $form->tab('会员配置',function (Form $form) {
            $form->text('members_price','会员售价')->default(Settings::get('members_price'));
            $form->image('members_poster','会员海报')->default(Settings::get('members_poster'))->url('files/uploads');
             $form->image('members_popup_poster','会员弹窗海报')->default(Settings::get('members_popup_poster'))->url('files/uploads');
        });
        $form->tab('关于页配置',function (Form $form) {
            $form->image('about_logo','LOGO')->default(Settings::get('about_logo'))->url('files/uploads');
            $form->text('about_title','标题')->default(Settings::get('about_title'));
            $form->text('about_copyright','版权')->default(Settings::get('about_copyright'));

        });

        $form->action('settings/wx');
        return $form;
    }


    public function wx(Request $request)
    {
        $AppID = $request->input('app_id');
        $AppSecret = $request->input('app_secret');
        $mch_id = $request->input('mch_id');
        $mch_secret = $request->input('mch_secret');
        if ($AppID || $AppSecret) {
            Settings::set('app_id',$AppID);
            Settings::set('app_secret',$AppSecret);
            Settings::set('mch_id',$mch_id);
            Settings::set('mch_secret',$mch_secret);
        }





        Settings::set('is_audit_posts',$request->input('is_audit_posts'));
        Settings::set('is_audit_comment',$request->input('is_audit_comment'));
        Settings::set('is_audit_user_info',$request->input('is_audit_user_info'));
        Settings::set('is_user_center_show_posts',$request->input('is_user_center_show_posts'));
        Settings::set('is_audit_create_cirlce',$request->input('is_audit_create_cirlce'));



        Settings::set('members_price',$request->input('members_price'));
        Settings::set('members_poster',$request->input('members_poster'));
        Settings::set('members_popup_poster',$request->input('members_popup_poster'));
        Settings::set('authentication_popup_poster',$request->input('authentication_popup_poster'));
        Settings::set('official_popup_poster',$request->input('official_popup_poster'));
        Settings::set('user_background_maps',$request->input('user_background_maps'));

        // 3
        Settings::set('app_title',$request->input('app_title'));
        Settings::set('app_intro',$request->input('app_intro'));
        Settings::set('app_login_bg',$request->input('app_login_bg'));





        // 4
        Settings::set('about_logo',$request->input('about_logo'));
        Settings::set('about_title',$request->input('about_title'));
        Settings::set('about_copyright',$request->input('about_copyright'));



        return $this->response()->success('成功！');
    }


    public function oss(Content $content, Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->post();

            if ($data['ossType'] == 'cosv5') {
                $configData = [
                    'bucket' => $data['bucket'],
                    'region' => $data['region'],
                    'appId' => $data['appId'],
                    'secretId' => $data['secretId'],
                    'secretKey' => $data['secretKey'],
                    'domain' => $data['domain']
                ];
                Settings::set('cosv5',$configData);
            }
            Settings::set('ossType',$data['ossType']);

            return $this->response()->success('保存成功！')->refresh();
        }
        $form = new Form();

        $form->radio('ossType')
            ->when('cosv5', function (Form $form) {
               $cosv5 = json_decode(Settings::get('cosv5'),true);

                $form->text('bucket', '存储空间名称 Bucket')->value($cosv5['bucket']);
                $form->text('region', '所属地域 Region')->value($cosv5['region']);
                $form->text('appId', 'AppId')->value($cosv5['appId']);
                $form->password('secretId', 'SecretId')->value($cosv5['secretId']);
                $form->password('secretKey', 'SecretKey')->value($cosv5['secretKey']);
                $form->url('domain', 'Domain')->value($cosv5['domain'])->help('请补全http:// 或 https://，例如：http://static.cloud.com');
            })
            ->options([
                'local' => '本地（不推荐）',
                'cosv5' => '腾讯云cos',
            ])
            ->value(Settings::get('ossType'))->default('local');

        return $content->title('上传设置')
            ->body(
                <<<HTML
<div class="card">{$form->render()}</div>
HTML
            );
    }
}
